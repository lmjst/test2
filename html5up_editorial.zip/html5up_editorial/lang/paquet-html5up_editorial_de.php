<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// H
	'html5up_editorial_description' => '',
	'html5up_editorial_nom' => 'Html5up Editorial ',
	'html5up_editorial_slogan' => 'responsives Skelett «Editorial» von HTML5UP',
);
