<?php
/**
 * Chargement du plugin Html5up Editorial
 *
 * @plugin     Html5up Editorial
 * @copyright  2017
 * @author     chankalan
 * @licence    GNU/GPL
 * @package    SPIP\Html5up_editorial\Options
 */

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS['z_blocs'] = array('content', 'head', 'head_js', 'breadcrumb', 'header', 'footer');


