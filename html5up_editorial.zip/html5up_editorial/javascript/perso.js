jQuery(function($){
	// bogue de main.js qui ne supprime pas cette classe, à tort
	$('body').removeClass('is-loading');
});